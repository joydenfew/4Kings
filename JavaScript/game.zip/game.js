var cardArray = [];
var KingsLeft = 4;
var cardColour = [];

//loads all the cards into the array
function loadArray() {
    "use strict";
    //loads all the face cards into the cardArray
    var tempArray = ["JK", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    while (tempArray.length > 0) {
        var temp = tempArray.pop(), i = 4;
        while (i > 0) {
            cardArray.push(temp);
            i = i - 1;
        
            if (tempArray.length % 2 === 0) {
            cardColour.push("#FF0000");
            }
            else {
                cardColour.push("#000000");
            }
            
        }
    }
    
    
}

function card(face,description,longDescription,colour) {
   this.cardFace=face;
   this.CardDescription=description;
   this.CardFullDescription=longDescription;
   this.cardColour=colour;
}


function nextCard() {
    "use strict";
    //document.getElementById("face").style.fontSize = (screen.width) + "px" ;
    
    var x = Math.floor(cardArray.length * Math.random());
    var y = cardArray[x];
    y = y.fontcolor(cardColour[x]);
    cardArray.splice(x, 1);
    if (y === "K") { 
        KingsLeft = KingsLeft - 1; 
    }
    document.getElementById("face").innerHTML = y;
    document.getElementById("pp").innerHTML = "DEBUG: " + y + " Cards left = " + cardArray.length + " Kings left = " + KingsLeft + " color = " + cardColour[x];


}


loadArray();



